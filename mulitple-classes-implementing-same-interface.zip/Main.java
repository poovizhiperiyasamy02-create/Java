interface payment
{
    void pay();
}
class googlepay implements payment
{
    public void pay()
    {
        System.out.println("paid using googlepay");
    }

}
class phonepe implements payment
{
    public void pay()
    {
        System.out.println("paid using phonepe");
    }
}
public class Main
{
    public static void main(String[] args)
    {
        payment p1=new googlepay();
        payment p2=new phonepe();
        p1.pay();
        p2.pay();
    }
}
