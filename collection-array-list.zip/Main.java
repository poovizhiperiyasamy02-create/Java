import java.util.ArrayList;
import java.util.List;
public class Main
{
	public static void main(String[] args) {
		List al=new ArrayList();
		al.add(10);
		al.add("java");
		al.add("python");
		al.add(100.55);
		al.remove("python");
		System.out.println(al);
	}
}