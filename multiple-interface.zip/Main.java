interface listening
{
    void listen();
}
interface playing
{
    void play();
}
class classroom implements listening,playing
{
    public void listen()
    {
        System.out.println("class is listening");
    }
    public void play()
    {
        System.out.println("class is playing");
    }
}
public class Main
{
    public static void main(String[] args)
    {
        classroom c=new classroom();
        c.listen();
        c.play();
    }
    
}
