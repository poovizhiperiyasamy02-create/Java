


	 
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
public class Main {
    public static void main(String[] args) {
        // 1. Empty list
        ArrayList<String> list1 = new ArrayList<>();
        ArrayList<Integer> list2 = new ArrayList<>(10);
        System.out.println(list1);
        System.out.println(list2);
        List<String> list3 = new ArrayList<>(Arrays.asList("apple", "banana", "cherry"));
		List<String> l=new ArrayList<>(); 
		System.out.println(list3);
		ArrayList<String> fruits = new ArrayList<>();
        fruits.add("Apple");
        fruits.add("Banana");
        fruits.add("Mango");
        fruits.add(1, "Grapes");
        System.out.println(fruits); 
        String fruit = fruits.get(2);
        System.out.println("Fruit at index 2: " + fruit);
        fruits.set(1, "Orange");
        System.out.println(fruits); 
        fruits.remove(2);               
        fruits.remove("Apple");         
        System.out.println(fruits);
        fruits.clear();         
        System.out.println(fruits); 
        System.out.println(fruits.size());   
        System.out.println(fruits.isEmpty());










    }
}
    




