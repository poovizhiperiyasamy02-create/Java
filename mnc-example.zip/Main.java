interface payment
{
    void pay(double amount);
}
class creditcard implements payment
{
    public void pay(double amount)
    {
        System.out.println("paid"+amount+"using creditcard");
    }
}
class upi implements payment
{
    public void pay(double amount)
    {
        System.out.println("paid"+amount+"using upi");
    }
}
public class Main
{
    public static void main(String[] args)
    {
        payment p;
        p=new creditcard();
        p.pay(5000);
        p=new upi();
        p.pay(2000);
    }
}
    
