public class Main
{
 public static void main (String[] args) 
{
    try{
        int a=10/0;
            System.out.println("can divide");
        
    }
    catch(Exception e){
        System.out.println("cannot divide");
    }
}
}    
