interface college
{
    int fees=50000;
}
public class Main
{
    public static void main(String[] args)
    {
        System.out.println(college.fees);
}
     
}

	
