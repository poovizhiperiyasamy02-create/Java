public class Main
{
	public static void main(String[] args) {
	AIDS_C b =new AIDS_C();
	b.give();
	b.got();
	}
}
class AIDS_A
{
    void give(){
        System.out.println("Chalk");
    }
}
class AIDS_B extends AIDS_A
{
    void get(){
        System.out.println("Duster");
    }
}
class AIDS_C extends AIDS_A 
{
    void got(){
        System.out.println("Lap");
    }
}

