interface vehicle
{
    void start();
}
interface car extends vehicle
{
    void drive();
}
class BMW implements car
{
    public void drive()
    {
        System.out.println("car is driving");
    }
    public void start()
    {
        System.out.println("car is started");
    }
}
public class Main
{
    public static void main(String[] args)
    {
        BMW b=new BMW();
        b.drive();
        b.start();
    }
}
