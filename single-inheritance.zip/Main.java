

public class Main
{
	public static void main(String[] args) {
	AIDS_B b =new AIDS_B();
	b.give();
	b.get();
	}
}
class AIDS_A
{
    void give(){
        System.out.println("Chalk");
    }
}
class AIDS_B extends AIDS_A
{
    void get(){
        System.out.println("Duster");
    }
}
